// script.js

const suits = ["♥", "♦", "♣", "♠"];
const ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
let deck = [];
let drawPile = [];
let discardPile = [];
let foundations = [[], [], [], []];
let tableaus = [[], [], [], [], [], [], []];
let draggedCard = null;

// Generate the deck
function createDeck() {
  suits.forEach(suit => {
    ranks.forEach((rank, value) => {
      const color = suit === "♥" || suit === "♦" ? "red" : "black";
      deck.push({ suit, rank, value, color });
    });
  });
  shuffleDeck();
}

// Shuffle the deck
function shuffleDeck() {
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
}

// Deal cards to the tableau
function dealCards() {
  let cardIndex = 0;
  tableaus.forEach((pile, i) => {
    for (let j = 0; j <= i; j++) {
      const card = deck[cardIndex++];
      card.faceUp = j === i; // Only the top card is face up
      pile.push(card);
    }
  });
  drawPile = deck.slice(cardIndex);
  updateUI();
}

// Update the game board UI
function updateUI() {
  updatePile("#draw-pile", drawPile.slice(-1), false);
  updatePile("#discard-pile", discardPile.slice(-1), false);

  foundations.forEach((foundation, i) =>
    updatePile(`[data-foundation="${i + 1}"]`, foundation, true)
  );

  tableaus.forEach((tableau, i) =>
    updatePile(`[data-tableau="${i + 1}"]`, tableau, true)
  );
}

// Update a specific pile
function updatePile(selector, pile, faceUpOnly) {
  const container = document.querySelector(selector);
  container.innerHTML = "";
  pile.forEach((card, index) => {
    if (faceUpOnly && !card.faceUp) return;
    const cardDiv = createCardElement(card);
    cardDiv.style.top = `${index * 20}px`;
    container.appendChild(cardDiv);
  });
}

// Create a card element
function createCardElement(card) {
  const cardDiv = document.createElement("div");
  cardDiv.classList.add("card");
  cardDiv.classList.add(card.color);
  cardDiv.textContent = card.faceUp ? `${card.rank} ${card.suit}` : "";
  cardDiv.draggable = true;

  cardDiv.addEventListener("dragstart", (e) => {
    draggedCard = card;
    e.dataTransfer.setData("text/plain", JSON.stringify(card));
  });

  cardDiv.addEventListener("dragend", () => {
    draggedCard = null;
  });

  return cardDiv;
}

// Handle dropping a card
function handleDrop(event, targetPile) {
  event.preventDefault();
  if (!draggedCard) return;

  const pile = tableaus[parseInt(targetPile.dataset.tableau, 10) - 1];
  pile.push(draggedCard);
  updateUI();
}

// Set up drag and drop
function setupDragAndDrop() {
  document.querySelectorAll(".pile").forEach(pile => {
    pile.addEventListener("dragover", (e) => e.preventDefault());
    pile.addEventListener("drop", (e) => handleDrop(e, pile));
  });
}

// Check for win condition
function checkWinCondition() {
  const allComplete = foundations.every(foundation => foundation.length === 13);
  if (allComplete) {
    document.getElementById("win-message").hidden = false;
  }
}

// Initialize the game
function initGame() {
  createDeck();
  dealCards();
  setupDragAndDrop();
}

// Start the game
initGame();
